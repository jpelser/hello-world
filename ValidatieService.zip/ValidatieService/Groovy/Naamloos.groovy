import com.parasoft.api.*
import groovy.xml.*
/*//////////////////////////////////////////////////*
* JW Assertions										*
* 													*
* 													*
* Author: Matthijs Drenth							*
* Oelan Test Consultancy/Zorginstituut Nederland	*
*///////////////////////////////////////////////////*/

/*//////////////////////////////////////////////////*
* JW 301 NR10										*
*///////////////////////////////////////////////////*/

def Assertion_JW301_NR10(Object input, ScriptingContext context) {
	//Load the incoming message into a usable object
	Message = context.getValue("Generated Data Source", "IncomingBericht")
	def Bericht = new XmlSlurper().parseText(Message)

	//Identify the TestCasenumber
	String TestCaseDS = context.getValue("JW301", "TestCase")
	message = "Identified JW301 NR10. Beginning check if all required fields are equal to expected results"

	Application.showMessage(message)
	Date date = new Date()
	File file = new File("pv.log")
    if(message != null){file << "${date} " + message + "\n"}


	//Add all DataSource columns which need to be checked in the incoming message
    List DS =	[
    			["01", "JW301", "BerichtCode"],
				["02", "JW301", "BerichtVersie"],

				//["03", "JW301", "Client/Beschikking/BeschikkingNummer"],
				["05", "JW301", "Client/Beschikking/Ingangsdatum"],
				["06", "JW301", "Client/Beschikking/Einddatum"],

				["12", "JW301", "Client/Beschikking/ToegewezenProducten/ToegewezenProduct/ReferentieAanbieder"],
				["14", "JW301", "Client/Beschikking/ToegewezenProducten/ToegewezenProduct/Product/Categorie"],
				["15", "JW301", "Client/Beschikking/ToegewezenProducten/ToegewezenProduct/Product/Code"],
				["16", "JW301", "Client/Beschikking/ToegewezenProducten/ToegewezenProduct/Aanbieder"],
				["18", "JW301", "Client/Beschikking/ToegewezenProducten/ToegewezenProduct/Omvang/Eenheid"],
				]

	//Add all XML fields which need to be checked
    List XML = 	[
				["01", "BerichtCode", Bericht.Header.BerichtCode.text()],
				["02", "BerichVersie", Bericht.Header.BerichtVersie.text()],

				//["03", "Beschikkingnummer", Bericht.Clienten.Client.Beschikking.BeschikkingNummer.text()],
				["05", "Ingangsdatum",  Bericht.Clienten.Client.Beschikking.Ingangsdatum.text()],
				["06", "Einddatum",  Bericht.Clienten.Client.Beschikking.Einddatum.text()],

				["12", "ReferentieAanbieder", Bericht.Clienten.Client.Beschikking.ToegewezenProducten.ToegewezenProduct.ReferentieAanbieder.text()],
				["14", "Categorie", Bericht.Clienten.Client.Beschikking.ToegewezenProducten.ToegewezenProduct.Product.Categorie.text()],
				["15", "Code", Bericht.Clienten.Client.Beschikking.ToegewezenProducten.ToegewezenProduct.Product.Code.text()],
				["16", "Aanbieder", Bericht.Clienten.Client.Beschikking.ToegewezenProducten.ToegewezenProduct.Aanbieder.text()],
				["18", "Eenheid", Bericht.Clienten.Client.Beschikking.ToegewezenProducten.ToegewezenProduct.Omvang.Eenheid.text()],
				]

	context.setValue("AssertionResults", assertXML(DS,XML, context))
}


/*//////////////////////////////////////////////////*
 * Function: assertXML 								*
 * function to assert two lists against eachother.	*
 * 													*
 * Author: Matthijs Drenth							*
 * Oelan Test Consultancy/Zorginstituut Nederland	*
 *//////////////////////////////////////////////////*/
import com.parasoft.api.*
import groovy.xml.*

def assertXML(List DSValues,List XMLValues, ScriptingContext context) {
	AssertFaults = []
	if (DSValues.size() == XMLValues.size()) {
		//Loop through the List with DataSource Columns to get each corresponding value
			DSValues.eachWithIndex {it, i->
				//Get value from datasource
				DSValue = context.getValue(it[1], it[2])
				if (DSValue == null) {DSValue = ""}
				 //Actual assertion
				 //Compare results between the value from the DataSource and the XML value
				 if (DSValue != XMLValues[i][2]){
					 AssertFaults.add("Element: \"${it[2]}\" met waarde \"${XMLValues[i][2]}\" voldoet niet aan verwachting;\n")
					 }
				 }

		}
	else {AssertFaults.add("<Fault><Code>0000</Code><Description>Error: #DSColumns != #XMLValues</Description>\n")}

	if (AssertFaults.size() == 0) {
		Application.showMessage("Message Validated OK")
		return result = ""
		}

	else {
		Application.showMessage("Message did not Validate OK")
		return result = "<Fault>\n<Code>000</Code>\n<Description>"+AssertFaults.join()+"</Description>\n</Fault>"

		}
}
