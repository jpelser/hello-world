import com.parasoft.api.*;
import com.parasoft.Application.*;

def getXmlAsBase64(Object input, ScriptingContext context){
    Application.showMessage("#### getXmlAsBase64")
    // String envId = context.getEnvironmentVariableValue("ENV_ID")

    // String TestCase = context.getValue("Test 1: Bericht")
    TestCase = context.getValue("Generated Data Source", "IncomingBericht")
    // getlocalDir()
    // String localDir = context.getAbsolutePathFile("Testbestanden")
    // String path = "${localDir}/JW501-NR10.xml"
    // String fileContents = new File(path).getText('UTF-8')
    // String encoded = TestCase.bytes.encodeBase64().toString()
    Application.showMessage("${TestCase}")
    // return encoded
}
